<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssionHLBmy extends ControllerPaymentPayssion {
	protected $pm_id = 'hlb_my';
}