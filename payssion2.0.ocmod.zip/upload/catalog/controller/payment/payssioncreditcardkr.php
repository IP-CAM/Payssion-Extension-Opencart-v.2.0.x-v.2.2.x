<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssionCreditcardkr extends ControllerPaymentPayssion {
    protected $pm_id = 'creditcard_kr';
}