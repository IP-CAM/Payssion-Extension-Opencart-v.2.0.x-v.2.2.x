<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssion7elevenmy extends ControllerPaymentPayssion {
	protected $pm_id = '7eleven_my';
}