<?php

require_once(realpath(dirname(__FILE__)) . "/payssion.php");
class ControllerPaymentPayssionPaycokr extends ControllerPaymentPayssion {
    protected $pm_id = 'payco_kr';
}