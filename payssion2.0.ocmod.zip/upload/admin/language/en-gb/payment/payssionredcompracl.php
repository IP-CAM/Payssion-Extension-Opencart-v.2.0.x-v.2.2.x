<?php
require_once(realpath(dirname(__FILE__)) . "/payssion.php");

$_['heading_title']					= 'Redcompra';
$_['text_payssionrecompracl']		= '<a href="https://www.payssion.com" target="_blank"><img src="view/image/payment/redcompra_cl.png" alt="Payssion" title="Payssion" style="border: 1px solid #EEEEEE;" /></a>';